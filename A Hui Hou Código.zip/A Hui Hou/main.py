import json
import os

ARCHIVO = "inventario.json"

# ------------------------------
# Funciones de manejo del JSON
# ------------------------------
def cargar_inventario():
    if not os.path.exists(ARCHIVO):
        return []
    with open(ARCHIVO, "r", encoding="utf-8") as f:
        return json.load(f)

def guardar_inventario(inventario):
    with open(ARCHIVO, "w", encoding="utf-8") as f:
        json.dump(inventario, f, indent=2, ensure_ascii=False)

# ------------------------------
# Funciones de inventario
# ------------------------------
def mostrar_inventario(inventario):
    if not inventario:
        print("\n📦 Inventario vacío.\n")
        return
    print("\n📋 Inventario actual:")
    for i, prod in enumerate(inventario, start=1):
        print(f"{i}. {prod['nombre']} | {prod['presentacion']} | Cant: {prod['cantidad']} | Precio: {prod['precio']}")
    print()

def agregar_producto(inventario):
    nombre = input("Nombre del producto: ").strip()
    presentacion = input("Presentación (ej: 500g, frasco, unidad): ").strip()
    try:
        cantidad = int(input("Cantidad: "))
    except ValueError:
        cantidad = 0
    try:
        precio = float(input("Precio (dejar vacío si no aplica): ") or 0)
    except ValueError:
        precio = 0

    inventario.append({
        "nombre": nombre,
        "presentacion": presentacion,
        "cantidad": cantidad,
        "precio": precio if precio > 0 else None
    })
    guardar_inventario(inventario)
    print("✅ Producto agregado con éxito.\n")

def editar_producto(inventario):
    mostrar_inventario(inventario)
    try:
        idx = int(input("Número de producto a editar: ")) - 1
        if idx < 0 or idx >= len(inventario):
            print("⚠️ Opción inválida.\n")
            return
    except ValueError:
        print("⚠️ Entrada inválida.\n")
        return

    prod = inventario[idx]
    print(f"\nEditando: {prod['nombre']} ({prod['presentacion']})")

    try:
        nueva_cant = int(input(f"Nueva cantidad (actual {prod['cantidad']}): ") or prod['cantidad'])
        nuevo_precio = input(f"Nuevo precio (actual {prod['precio']}): ")
        prod['cantidad'] = nueva_cant
        prod['precio'] = float(nuevo_precio) if nuevo_precio.strip() else prod['precio']
    except ValueError:
        print("⚠️ Datos inválidos, no se aplicaron cambios.\n")
        return

    guardar_inventario(inventario)
    print("✅ Producto actualizado.\n")

def eliminar_producto(inventario):
    mostrar_inventario(inventario)
    try:
        idx = int(input("Número de producto a eliminar: ")) - 1
        if idx < 0 or idx >= len(inventario):
            print("⚠️ Opción inválida.\n")
            return
    except ValueError:
        print("⚠️ Entrada inválida.\n")
        return

    eliminado = inventario.pop(idx)
    guardar_inventario(inventario)
    print(f"🗑️ Producto eliminado: {eliminado['nombre']} ({eliminado['presentacion']})\n")

# ------------------------------
# Menú principal
# ------------------------------
def menu():
    inventario = cargar_inventario()
    while True:
        print("=== SISTEMA DE INVENTARIO - A Hui Hou ===")
        print("1. Ver inventario")
        print("2. Agregar producto")
        print("3. Editar producto")
        print("4. Eliminar producto")
        print("5. Salir")
        opcion = input("Seleccione una opción: ").strip()

        if opcion == "1":
            mostrar_inventario(inventario)
        elif opcion == "2":
            agregar_producto(inventario)
        elif opcion == "3":
            editar_producto(inventario)
        elif opcion == "4":
            eliminar_producto(inventario)
        elif opcion == "5":
            print("👋 Saliendo del sistema...")
            break
        else:
            print("⚠️ Opción inválida, intente nuevamente.\n")

if __name__ == "__main__":
    menu()
