
import json
import builtins

# Nota: 'app' es el fixture definido en conftest.py que te da acceso a main.py con un inventario temporal.

def test_cargar_inventario_vacio(app):
    inv = app.cargar_inventario()
    assert inv == []

def test_mostrar_inventario_vacio(app, capsys):
    app.mostrar_inventario([])
    out = capsys.readouterr().out
    assert "Inventario vacío" in out

def test_agregar_producto(app, monkeypatch):
    # Simula entradas del usuario: nombre, presentacion, cantidad, precio
    inputs = ["Cafe", "500g", "3", "25000"]
    monkeypatch.setattr("builtins.input", lambda _: inputs.pop(0))

    inventario = []
    app.agregar_producto(inventario)

    assert len(inventario) == 1
    p = inventario[0]
    assert p["nombre"] == "Cafe"
    assert p["presentacion"] == "500g"
    assert p["cantidad"] == 3
    assert p["precio"] == 25000.0

    # Verifica que quedó guardado en el JSON temporal
    loaded = app.cargar_inventario()
    assert any(x["nombre"] == "Cafe" and x["cantidad"] == 3 for x in loaded)

def test_editar_producto(app, monkeypatch, capsys):
    # Crea un inventario con 1 producto y guárdalo
    inventario = [{
        "nombre": "Granola",
        "presentacion": "paquete 1lb",
        "cantidad": 2,
        "precio": None
    }]
    app.guardar_inventario(inventario)

    # Simula: elegir producto 1, nueva cantidad=10, nuevo precio=11900
    inputs = ["1", "10", "11900"]
    monkeypatch.setattr("builtins.input", lambda _: inputs.pop(0))

    app.editar_producto(inventario)

    assert inventario[0]["cantidad"] == 10
    assert inventario[0]["precio"] == 11900.0

def test_eliminar_producto(app, monkeypatch):
    inventario = [
        {"nombre": "A", "presentacion": "unidad", "cantidad": 1, "precio": None},
        {"nombre": "B", "presentacion": "unidad", "cantidad": 2, "precio": None},
    ]
    app.guardar_inventario(inventario)

    # Elimina el primero
    inputs = ["1"]
    monkeypatch.setattr("builtins.input", lambda _: inputs.pop(0))

    app.eliminar_producto(inventario)

    assert len(inventario) == 1
    assert inventario[0]["nombre"] == "B"
