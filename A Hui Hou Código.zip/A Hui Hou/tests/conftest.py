
import pytest
import main  # Importa tu app de consola

@pytest.fixture
def app(monkeypatch, tmp_path):
    """Prepara un inventario temporal y redirige main.ARCHIVO a ese archivo.
    Así las pruebas NO tocan tu inventario real.
    """
    tmp_file = tmp_path / "inventario.json"
    tmp_file.write_text("[]", encoding="utf-8")
    # Parchea el path del archivo usado por main.py
    monkeypatch.setattr(main, "ARCHIVO", str(tmp_file))
    return main
